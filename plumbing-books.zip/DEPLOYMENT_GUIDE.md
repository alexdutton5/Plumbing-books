# 🚀 How to Deploy Your Plumbing Books App Online

## Quick Start (5 minutes)

### Step 1: Create a GitHub Account (if you don't have one)
- Go to https://github.com/signup
- Sign up with your email
- Verify your email

### Step 2: Create a GitHub Repository
- Go to https://github.com/new
- Repository name: `plumbing-books` (or whatever you like)
- Description: "Smart bookkeeping for my plumbing business"
- Choose "Public"
- Click "Create repository"

### Step 3: Upload Your Code
- After creating the repo, you'll see an empty repository
- Click "uploading an existing file"
- Download all these files from this folder:
  - package.json
  - README.md
  - All files in the `src/` folder
  - All files in the `public/` folder
  - .gitignore
- Drag and drop them into the GitHub upload box
- Click "Commit changes"

### Step 4: Deploy to Vercel (Free Hosting)
- Go to https://vercel.com
- Click "Sign Up" 
- Choose "Continue with GitHub"
- Authorize Vercel to access your GitHub
- Click "New Project"
- Select your "plumbing-books" repository
- Click "Import"
- Click "Deploy"
- **Wait 2-3 minutes...**

### Step 5: Access Your App
- You'll get a URL like `plumbing-books.vercel.app`
- This is your app! Bookmark it
- You can use it on any device

## That's It! 🎉

Your app is now online and will remember all your data. You can:
- Upload bank statements from anywhere
- Add expenses and invoices
- View your monthly profit/loss
- Everything saves automatically

## Troubleshooting

**"Error during deployment"**
- Make sure all files are uploaded to GitHub correctly
- Check that package.json is in the root folder

**"Page not found"**
- Wait a few minutes and refresh
- Vercel sometimes takes a moment to build

**"Lost my data"**
- Your data is saved in your browser
- If you clear your browser cache, it deletes the data
- The data is specific to each device/browser

## Updating Your App

If you want to make changes:
1. Download the updated files
2. Go to your GitHub repository
3. Upload the new files (they'll replace the old ones)
4. Vercel automatically redeploys

## Support

If you get stuck:
- GitHub Help: https://docs.github.com
- Vercel Docs: https://vercel.com/docs
- Reach out with screenshots of any errors
