# Plumbing Pro Books

A smart bookkeeping app for plumbing businesses. Upload bank statements, track expenses by category, and see your monthly profit/loss instantly.

## Features

- 📤 Upload bank statements (PDF, CSV, TXT)
- 📊 Automatic expense categorization
- 💰 Monthly profit/loss dashboard
- 📱 Mobile-friendly design
- 💾 Data saves automatically

## Deploy to Vercel (Easiest)

1. Go to https://github.com/new and create a new repository
2. Upload all the files from this folder
3. Go to https://vercel.com and sign up (free)
4. Click "New Project"
5. Connect your GitHub repository
6. Click "Deploy"
7. Your app will be live at a URL like `yourapp.vercel.app`

## Run Locally

```bash
npm install
npm start
```

The app opens at `http://localhost:3000`

## How to Use

1. **Upload Statement** - Click "Upload Statement" and select your bank statement PDF or CSV
2. **Paste Transactions** - Or copy/paste transaction data from your bank
3. **Add Manually** - Click "Add Expense" or "Add Invoice" to enter data manually
4. **View Reports** - Check the Dashboard for your monthly P&L

## Data Storage

All your data is saved locally in your browser. It persists between sessions automatically.

## Support

For issues or questions, contact support.
