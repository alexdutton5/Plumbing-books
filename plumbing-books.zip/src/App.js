import PlumbingBookkeeper from './PlumbingBookkeeper';

function App() {
  return <PlumbingBookkeeper />;
}

export default App;
