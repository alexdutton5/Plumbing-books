import React, { useState, useEffect } from 'react';
import { Trash2, TrendingUp, DollarSign, Plus, X, Upload } from 'lucide-react';

export default function PlumbingBookkeeper() {
  const [entries, setEntries] = useState([
    { id: 1, type: 'expense', amount: 328.16, description: 'SP EVREE - Business Supplies', date: '01/16/2025', month: '2025-01', category: 'Office & Admin' },
    { id: 2, type: 'expense', amount: 106.76, description: 'REPUBLIC SERVICES TRASH', date: '12/20/2024', month: '2024-12', category: 'Utilities & Communications' },
    { id: 3, type: 'expense', amount: 1.71, description: 'QT 1404 GILBERT AZ', date: '12/21/2024', month: '2024-12', category: 'Transportation' },
    { id: 22, type: 'expense', amount: 3028.16, description: 'SP EVREE SENSATIONS - Major Purchase', date: '01/11/2025', month: '2025-01', category: 'Equipment' },
  ]);

  const [currentMonth, setCurrentMonth] = useState(new Date(2025, 0, 1));
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showAddModal, setShowAddModal] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadedStatements, setUploadedStatements] = useState([]);
  const [processingPDF, setProcessingPDF] = useState(false);
  const [formData, setFormData] = useState({ amount: '', description: '', category: 'Other', date: '', clientName: '' });

  useEffect(() => {
    const saveData = async () => {
      try {
        await window.storage.set('plumbing-entries', JSON.stringify(entries));
        await window.storage.set('plumbing-statements', JSON.stringify(uploadedStatements));
      } catch (error) {
        console.error('Failed to save data');
      }
    };
    saveData();
  }, [entries, uploadedStatements]);

  const extractTextFromPDF = async (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          // For now, we'll ask the user to paste the text from the PDF
          // In a real app, you'd use a library like pdf.js or pdfplumber
          const text = await navigator.clipboard.readText().catch(() => null);
          
          if (text) {
            resolve(text);
          } else {
            // Fallback: Show instructions
            resolve('PASTE_NEEDED');
          }
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = reject;
      reader.readAsText(file);
    });
  };

  const parseTransactionsFromText = (text) => {
    // This regex looks for transaction patterns in bank statements
    // Format: Date | Description | Amount
    const transactions = [];
    const lines = text.split('\n');

    lines.forEach((line) => {
      // Look for lines with dates and amounts
      const datePattern = /(\d{1,2}\/\d{1,2}|\d{1,2}-\d{1,2})/;
      const amountPattern = /\$?\s?(\d+[\d,]*\.?\d{2})/g;

      const dateMatch = line.match(datePattern);
      const amounts = line.match(amountPattern);

      if (dateMatch && amounts && amounts.length > 0) {
        const date = dateMatch[0];
        const amount = parseFloat(amounts[amounts.length - 1].replace(/[$,]/g, ''));
        
        // Extract description (everything between date and amount)
        const parts = line.split(dateMatch[0]);
        let description = parts[1] || '';
        
        // Remove amount from description
        amounts.forEach(amt => {
          description = description.replace(amt, '').trim();
        });

        if (description && amount > 0) {
          transactions.push({
            date,
            description: description.substring(0, 60),
            amount,
          });
        }
      }
    });

    return transactions;
  };

  const categorizeExpense = (description) => {
    const desc = description.toLowerCase();
    if (desc.includes('home depot') || desc.includes('lowes') || desc.includes('supply')) {
      return 'Materials & Supplies';
    }
    if (desc.includes('uber') || desc.includes('gas') || desc.includes('fuel')) {
      return 'Transportation';
    }
    if (desc.includes('amazon') || desc.includes('tool')) {
      return 'Equipment';
    }
    if (desc.includes('office') || desc.includes('staples')) {
      return 'Office & Admin';
    }
    return 'Other';
  };

  const handlePDFUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setProcessingPDF(true);

    try {
      // Read the file
      const text = await file.text().catch(() => {
        // If it's a PDF, we need special handling
        alert('For PDF files, please:\n1. Open the PDF\n2. Copy the transaction text\n3. Click "Paste Transactions" button');
        return null;
      });

      if (text) {
        const transactions = parseTransactionsFromText(text);
        
        if (transactions.length > 0) {
          const newEntries = transactions.map((t, idx) => ({
            id: Math.max(...entries.map(e => e.id), 0) + idx + 1,
            type: 'expense',
            amount: t.amount,
            description: t.description,
            date: `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}-${t.date.padStart(2, '0')}`,
            month: currentMonth.toISOString().slice(0, 7),
            category: categorizeExpense(t.description),
          }));

          setEntries([...entries, ...newEntries]);
          setUploadedStatements([...uploadedStatements, { name: file.name, count: transactions.length, date: new Date().toLocaleDateString() }]);
          alert(`✅ Imported ${transactions.length} transactions from ${file.name}`);
          setShowUploadModal(false);
        } else {
          alert('Could not find transactions. Make sure the file is a valid bank statement.');
        }
      }
    } catch (error) {
      alert('Error processing file. Please try again.');
    }

    setProcessingPDF(false);
  };

  const handlePasteTransactions = async () => {
    try {
      const text = await navigator.clipboard.readText();
      const transactions = parseTransactionsFromText(text);

      if (transactions.length > 0) {
        const newEntries = transactions.map((t, idx) => ({
          id: Math.max(...entries.map(e => e.id), 0) + idx + 1,
          type: 'expense',
          amount: t.amount,
          description: t.description,
          date: new Date().toISOString().split('T')[0],
          month: currentMonth.toISOString().slice(0, 7),
          category: categorizeExpense(t.description),
        }));

        setEntries([...entries, ...newEntries]);
        setUploadedStatements([...uploadedStatements, { name: 'Pasted Statement', count: transactions.length, date: new Date().toLocaleDateString() }]);
        alert(`✅ Imported ${transactions.length} transactions!`);
        setShowUploadModal(false);
      } else {
        alert('Could not find transactions in clipboard. Make sure you copied transaction data from your bank statement.');
      }
    } catch (error) {
      alert('Could not access clipboard. Please copy your bank statement transactions first.');
    }
  };

  const handleAddSubmit = (type) => {
    if (!formData.amount || !formData.description) {
      alert('Please fill in all fields');
      return;
    }

    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    const date = formData.date || new Date().toISOString().split('T')[0];

    if (type === 'expense') {
      const newEntry = {
        id: Math.max(...entries.map(e => e.id), 0) + 1,
        type: 'expense',
        amount,
        description: formData.description,
        date,
        month: currentMonth.toISOString().slice(0, 7),
        category: formData.category || 'Other',
      };
      setEntries([...entries, newEntry]);
    } else if (type === 'invoice') {
      const newEntry = {
        id: Math.max(...entries.map(e => e.id), 0) + 1,
        type: 'invoice',
        amount,
        description: `Invoice #${formData.description} - ${formData.clientName || 'Client'}`,
        date,
        month: currentMonth.toISOString().slice(0, 7),
        isInvoice: true,
      };
      setEntries([...entries, newEntry]);
    }

    setFormData({ amount: '', description: '', category: 'Other', date: '', clientName: '' });
    setShowAddModal(null);
  };

  const handleDelete = (id) => {
    setEntries(entries.filter(entry => entry.id !== id));
  };

  const monthString = currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  const monthKey = currentMonth.toISOString().slice(0, 7);

  const monthEntries = entries.filter(e => e.month === monthKey);
  const invoices = monthEntries.filter(e => e.isInvoice);
  const expenses = monthEntries.filter(e => !e.isInvoice);

  const totalIncome = invoices.reduce((sum, e) => sum + e.amount, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const profit = totalIncome - totalExpenses;

  const expensesByCategory = expenses.reduce((acc, e) => {
    const cat = e.category || 'Other';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(e);
    return acc;
  }, {});

  const prevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-lg p-6 max-w-md w-full border border-slate-700">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">Upload Bank Statement</h2>
              <button onClick={() => setShowUploadModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              {/* File Upload */}
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Upload PDF or CSV</label>
                <label className="block">
                  <input
                    type="file"
                    accept=".pdf,.csv,.txt"
                    onChange={handlePDFUpload}
                    className="hidden"
                    disabled={processingPDF}
                  />
                  <div className="bg-slate-700 border-2 border-dashed border-slate-600 rounded px-4 py-6 text-center cursor-pointer hover:border-blue-500 transition">
                    <Upload className="w-8 h-8 mx-auto mb-2 text-slate-400" />
                    <p className="text-slate-300 text-sm font-medium">Click to upload statement</p>
                    <p className="text-slate-500 text-xs mt-1">PDF, CSV, or TXT</p>
                  </div>
                </label>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-600"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-slate-800 text-slate-400">Or</span>
                </div>
              </div>

              {/* Paste Option */}
              <div>
                <button
                  onClick={handlePasteTransactions}
                  className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium transition"
                >
                  Paste Transactions from Clipboard
                </button>
                <p className="text-slate-400 text-xs mt-2">Copy transaction data from your PDF and paste here</p>
              </div>

              <div className="bg-blue-900/20 border border-blue-600/30 rounded p-3">
                <p className="text-blue-300 text-xs">
                  <strong>Tip:</strong> Open your bank statement PDF, select and copy the transaction table, then paste it here.
                </p>
              </div>

              <button
                onClick={() => setShowUploadModal(false)}
                className="w-full px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded font-medium transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-lg p-6 max-w-md w-full border border-slate-700">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">
                {showAddModal === 'expense' ? 'Add Expense' : 'Add Invoice'}
              </h2>
              <button onClick={() => setShowAddModal(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Amount ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white"
                  placeholder="0.00"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  {showAddModal === 'expense' ? 'Description' : 'Invoice Number'}
                </label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white"
                  placeholder={showAddModal === 'expense' ? 'e.g., Home Depot supplies' : 'e.g., #001'}
                />
              </div>

              {showAddModal === 'expense' && (
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white"
                  >
                    <option>Office & Admin</option>
                    <option>Equipment</option>
                    <option>Transportation</option>
                    <option>Materials & Supplies</option>
                    <option>Utilities & Communications</option>
                    <option>Other</option>
                  </select>
                </div>
              )}

              {showAddModal === 'invoice' && (
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Client Name</label>
                  <input
                    type="text"
                    value={formData.clientName || ''}
                    onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                    className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white"
                    placeholder="e.g., John Smith"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white"
                />
              </div>

              <div className="flex gap-2 pt-4">
                <button
                  onClick={() => setShowAddModal(null)}
                  className="flex-1 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded font-medium transition"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleAddSubmit(showAddModal)}
                  className={`flex-1 px-4 py-2 rounded font-medium transition text-white ${
                    showAddModal === 'expense' ? 'bg-blue-600 hover:bg-blue-500' : 'bg-green-600 hover:bg-green-500'
                  }`}
                >
                  Add {showAddModal === 'expense' ? 'Expense' : 'Invoice'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 py-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <DollarSign className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Plumbing Pro Books</h1>
              <p className="text-slate-400 text-sm">Smart bookkeeping for your business</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Month Navigation */}
        <div className="flex items-center justify-between mb-8">
          <button onClick={prevMonth} className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition font-medium">
            ← Previous
          </button>
          <h2 className="text-2xl font-bold text-white">{monthString}</h2>
          <button onClick={nextMonth} className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition font-medium">
            Next →
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6 border-b border-slate-700 overflow-x-auto">
          {['dashboard', 'expenses', 'invoices'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 font-semibold transition capitalize whitespace-nowrap ${
                activeTab === tab
                  ? 'text-blue-400 border-b-2 border-blue-400'
                  : 'text-slate-400 hover:text-slate-300'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* P&L Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gradient-to-br from-green-900/40 to-green-800/20 border border-green-600/30 rounded-lg p-6">
                <p className="text-green-400 text-sm font-semibold mb-2">Total Income</p>
                <p className="text-4xl font-bold text-green-300">${totalIncome.toFixed(2)}</p>
                <p className="text-green-600/80 text-xs mt-3">{invoices.length} invoice(s)</p>
              </div>

              <div className="bg-gradient-to-br from-red-900/40 to-red-800/20 border border-red-600/30 rounded-lg p-6">
                <p className="text-red-400 text-sm font-semibold mb-2">Total Expenses</p>
                <p className="text-4xl font-bold text-red-300">${totalExpenses.toFixed(2)}</p>
                <p className="text-red-600/80 text-xs mt-3">{expenses.length} transaction(s)</p>
              </div>

              <div className={`bg-gradient-to-br ${profit >= 0 ? 'from-blue-900/40 to-blue-800/20 border border-blue-600/30' : 'from-orange-900/40 to-orange-800/20 border border-orange-600/30'} rounded-lg p-6`}>
                <p className={`${profit >= 0 ? 'text-blue-400' : 'text-orange-400'} text-sm font-semibold mb-2`}>Net Profit/Loss</p>
                <p className={`text-4xl font-bold ${profit >= 0 ? 'text-blue-300' : 'text-orange-300'}`}>${profit.toFixed(2)}</p>
                <p className={`text-xs mt-3 ${profit >= 0 ? 'text-blue-600/80' : 'text-orange-600/80'}`}>{profit >= 0 ? '📈 Positive' : '📉 Negative'}</p>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button onClick={() => setShowUploadModal(true)} className="flex items-center gap-3 p-4 bg-purple-600 hover:bg-purple-500 text-white rounded-lg transition font-medium">
                <Upload className="w-5 h-5" />
                Upload Statement
              </button>
              <button onClick={() => setShowAddModal('expense')} className="flex items-center gap-3 p-4 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition font-medium">
                <Plus className="w-5 h-5" />
                Add Expense
              </button>
              <button onClick={() => setShowAddModal('invoice')} className="flex items-center gap-3 p-4 bg-green-600 hover:bg-green-500 text-white rounded-lg transition font-medium">
                <Plus className="w-5 h-5" />
                Add Invoice
              </button>
            </div>

            {/* Uploaded Statements */}
            {uploadedStatements.length > 0 && (
              <div className="bg-slate-800 rounded-lg p-6">
                <h3 className="font-semibold text-white mb-4">Imported Statements</h3>
                <div className="space-y-2">
                  {uploadedStatements.map((stmt, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-slate-700/50 p-3 rounded">
                      <div>
                        <p className="text-slate-300 font-medium">{stmt.name}</p>
                        <p className="text-slate-500 text-xs">{stmt.count} transactions • {stmt.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Monthly Summary */}
            <div className="bg-slate-800 rounded-lg p-6">
              <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Monthly Breakdown
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center pb-4 border-b border-slate-700">
                  <span className="text-slate-400">Total Income</span>
                  <span className="text-green-400 font-semibold">${totalIncome.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center pb-4 border-b border-slate-700">
                  <span className="text-slate-400">Total Expenses</span>
                  <span className="text-red-400 font-semibold">${totalExpenses.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center pt-2 bg-slate-700/30 px-4 py-3 rounded">
                  <span className="text-white font-semibold">Net Profit/Loss</span>
                  <span className={`text-lg font-bold ${profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>${profit.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Expenses Tab */}
        {activeTab === 'expenses' && (
          <div className="space-y-4">
            <button onClick={() => setShowAddModal('expense')} className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition font-medium mb-4">
              <Plus className="w-5 h-5" />
              Add Expense
            </button>

            {expenses.length > 0 ? (
              <div className="space-y-4">
                {Object.entries(expensesByCategory)
                  .sort((a, b) => b[1].reduce((sum, e) => sum + e.amount, 0) - a[1].reduce((sum, e) => sum + e.amount, 0))
                  .map(([category, items]) => (
                    <div key={category} className="bg-slate-800 rounded-lg overflow-hidden">
                      <div className="bg-slate-700/50 p-4">
                        <div className="flex justify-between items-center">
                          <h3 className="font-semibold text-slate-100">{category}</h3>
                          <span className="text-slate-300 font-semibold">${items.reduce((sum, e) => sum + e.amount, 0).toFixed(2)}</span>
                        </div>
                      </div>
                      <div className="divide-y divide-slate-700">
                        {items.map(expense => (
                          <div key={expense.id} className="grid grid-cols-12 gap-4 p-4 items-center hover:bg-slate-700/30 transition">
                            <div className="col-span-6">
                              <p className="text-slate-100 font-medium text-sm">{expense.description}</p>
                              <p className="text-slate-500 text-xs">{expense.date}</p>
                            </div>
                            <div className="col-span-3">
                              <p className="text-slate-100 font-semibold">${expense.amount.toFixed(2)}</p>
                            </div>
                            <div className="col-span-3 flex justify-end">
                              <button onClick={() => handleDelete(expense.id)} className="text-red-400 hover:text-red-300 transition">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
              </div>
            ) : (
              <div className="bg-slate-800 rounded-lg p-12 text-center text-slate-400">
                <p>No expenses for {monthString}</p>
              </div>
            )}
          </div>
        )}

        {/* Invoices Tab */}
        {activeTab === 'invoices' && (
          <div className="space-y-4">
            <button onClick={() => setShowAddModal('invoice')} className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-500 text-white rounded-lg transition font-medium mb-4">
              <Plus className="w-5 h-5" />
              Add Invoice
            </button>

            {invoices.length > 0 ? (
              <div className="bg-slate-800 rounded-lg overflow-hidden">
                <div className="grid grid-cols-12 gap-4 p-4 bg-slate-700/50 font-semibold text-slate-300 text-sm">
                  <div className="col-span-7">Client</div>
                  <div className="col-span-3">Amount</div>
                  <div className="col-span-2">Action</div>
                </div>
                <div className="divide-y divide-slate-700">
                  {invoices.map(invoice => (
                    <div key={invoice.id} className="grid grid-cols-12 gap-4 p-4 items-center hover:bg-slate-700/30 transition">
                      <div className="col-span-7">
                        <p className="text-slate-100 font-medium text-sm">{invoice.description}</p>
                        <p className="text-slate-500 text-xs">{invoice.date}</p>
                      </div>
                      <div className="col-span-3">
                        <p className="text-green-400 font-semibold">${invoice.amount.toFixed(2)}</p>
                      </div>
                      <div className="col-span-2 flex justify-end">
                        <button onClick={() => handleDelete(invoice.id)} className="text-red-400 hover:text-red-300 transition">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-slate-800 rounded-lg p-12 text-center text-slate-400">
                <p>No invoices added yet. Click "Add Invoice" to get started.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
